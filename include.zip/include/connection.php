<?php

define("DB_HOST", "localhost");
define("DB_USER", "lidostec_ures");
define("DB_PASSWORD", "ures123456");
define("DB_NAME", "lidostec_ures");
define('FIREBASE_API_KEY', 'AIzaSyCOmvUi2-_cQFkit8_92DnaP8r1jGVVQvM');
?>
